package com.example.snowex01;

public class Address {
    String name;
    String phone;

    public Address(String name, String phone) {
        this.name = name;
        this.phone = phone;
    }

    public String getName() {
        return name;
    }

    public String getPhone() {
        return phone;
    }
}
