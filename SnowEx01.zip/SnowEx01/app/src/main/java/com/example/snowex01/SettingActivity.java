package com.example.snowex01;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class SettingActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_setting);


        Button addressList = (Button) findViewById(R.id.btn_address);
        Button SetETbtn = (Button) findViewById(R.id.btnSetET);
        addressList.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), PListActivity.class);
                startActivity(intent);
            }
        });

        SetETbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), EtextActivity.class);
                startActivity(intent);
            }
        });

    }
}